import java.util.Scanner;

class Main {
  public static void main(String[] args) {
	  
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the first number:");
	int f = sc.nextInt();
	System.out.println("enter the second number:");
	int s = sc.nextInt();
	System.out.println("Enter the number of terms:");
    int  n = sc.nextInt();
    System.out.println("Fibonacci Series till " + n + " terms:");
    
    for(int i = f;i <= n; i++) {
    	System.out.print(f + ", ");
    	int temp = f+s;
    	f=s;
    	s= temp;
    }
  }
}