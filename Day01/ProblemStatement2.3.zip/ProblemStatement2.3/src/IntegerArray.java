import java.util.Arrays;

public class IntegerArray {  
    public static void main(String[] args) {  
        //Initialize array  
        int arr[] = {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};  
        int sum = 0; int i; 
        //Loop through the array to calculate sum of elements  
        for ( i = 0; i < arr.length; i++) {  
           sum = sum + arr[i]; 
           //System.out.print(arr[i]+" ");
           
        }
           System.out.println();
           System.out.println("Sum of the array elements is : " + sum); 
           arr[arr.length-3]=sum;
           System.out.println("15th index value in arraylist is: " +arr[15]);
           double avr = (sum / arr.length);
           System.out.println("Average value of the array elements is : " + avr); 
           arr[arr.length-2]=(int) avr;
           System.out.println("16th index value in arraylist  is :" +arr[16]);
           System.out.println("Smallest value in arraylist is: "+ getSmallest(arr,17));
           arr[arr.length-1]=arr[0];
           System.out.println("17th index value in arraylist  is :" +arr[17]);
          
    }

    public static int getSmallest(int[] arr, int total){  
    	Arrays.sort(arr);  
    	return arr[0];  
    	}  
	}